package com.example.studentinfoapp.model;

public class Student {
    private String id;
    private String name;
    private String phone;
    private String address;

    public Student(String id, String name, String phone, String address) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.address = address;
    }

    public String getId()    { return id; }
    public String getName()  { return name; }
    public String getPhone() { return phone; }
    public String getAddress(){ return address; }
}
