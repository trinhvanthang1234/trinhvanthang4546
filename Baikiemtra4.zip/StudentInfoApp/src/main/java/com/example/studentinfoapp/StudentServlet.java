package com.example.studentinfoapp;

import com.example.studentinfoapp.model.Student;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/student")
public class StudentServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {
        // Lấy từ form
        String id      = request.getParameter("id");
        String name    = request.getParameter("name");
        String phone   = request.getParameter("phone");
        String address = request.getParameter("address");

        // Tạo bean và đẩy sang JSP
        Student student = new Student(id, name, phone, address);
        request.setAttribute("student", student);
        request.getRequestDispatcher("student.jsp")
               .forward(request, response);
    }

    // Nếu muốn, bạn vẫn giữ doGet để test nhanh
    @Override
    protected void doGet(HttpServletRequest req,
                         HttpServletResponse resp)
            throws ServletException, IOException {
        resp.sendRedirect("index.jsp");
    }
}
